package org.undp.log;


public interface Logable
{

    public abstract String getLogString();
}
