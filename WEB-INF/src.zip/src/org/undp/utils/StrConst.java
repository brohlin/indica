// Decompiled by DJ v3.12.12.96 Copyright 2011 Atanas Neshkov  Date: 5/6/2013 4:05:54 PM
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3)
// Source File Name:   StrConst.java

package org.undp.utils;


public class StrConst
{

    public StrConst()
    {
    }

    public static final String cEmptyStr = "";
    public static final String cLineTermStr = "\n";
    public static final String cHorizontalTab = "\t";
    public static final String cSpaceStr = " ";
    public static final String cDQuoteStr = "\"";
    public static final String cQuoteStr = "'";
    public static final String cCommaStr = ",";
    public static final char cLineTermChar = 10;
    public static final char cSpaceChar = 32;
    public static final char cQuoteChar = 39;
    public static final char cDQuoteChar = 34;
    public static final char cCommaChar = 44;
    public static final String cYesStr = "Yes";
    public static final String cNoStr = "No";
}
