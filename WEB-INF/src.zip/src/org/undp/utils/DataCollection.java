package org.undp.utils;

import org.undp.utils.arrays.DynObjectArray;
import org.undp.utils.arrays.DynStringArray;
import org.undp.utils.DbResults;
import java.io.PrintStream;
import java.io.Serializable;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.*;

public class DataCollection
{

    public DataCollection()
    {

    }


    public static final String generateFormOrganizationProfile(DbResults aDb,int aStartHideCol ,int aEndHideCol,int aStartCol,int aEndCol,int aTextStartCol,int aTextEndCol)
    {
        String vRowClass = "datatablerow";

        StringBuffer sOut = new StringBuffer(4096);

        if(aDb.hasRows())
        {
            sOut.append("<table align=\"center\" border=\"0\">").append("<tr class=\"datatableheaderrow\">");
            for(int x = 0; x < aDb.getColCount(); x++)

            	if (x >= aStartHideCol && x <= aEndHideCol) {
            		// do nothing
            	} else {
            		sOut.append("<th class=\"datatableheader\">").append(aDb.getColNames().get(x)).append("</th>");
            	}

            sOut.append("</tr>");

            aDb.moveFirst();
            do
            {
            	sOut.append("<form action=\"/uclbp/main.jsp?target=profile\" method=\"post\" name=\"insdata\">");
            	sOut.append("<input type=\"hidden\" name=\"ins_metric_organization\" value=\"y\">");
            	sOut.append("<tr class=" + vRowClass + ">");
                for(int x = 0; x < aDb.getColCount(); x++) {

                    if (x >= aStartHideCol && x <= aEndHideCol) {
                    	// sOut.append(getValue(x));
                    	sOut.append("<input type=\"hidden\" name=\"");
                    	sOut.append(x);
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\">");
                    } else if (x >= aStartCol && x <= aEndCol) {
                    	sOut.append("<td align=\"right\">");
                    	sOut.append("<select tabindex=\"<%= mCounter++ %>\" name=\"");
                    	sOut.append(x);
                    	sOut.append("\" size=\"1\">");


                    	sOut.append("<option value=\"N\" ");
                		if (aDb.getValue(x).equals("N")) {
                			sOut.append(" selected");
                		}
                		sOut.append(">No</option>");

                    	sOut.append("<option value=\"Y\" ");
                		if (aDb.getValue(x).equals("Y")) {
                			sOut.append(" selected");
                		}
                		sOut.append(">Yes</option>");


                    	sOut.append("</td>");
                    } else if (x >= aTextStartCol && x <= aTextEndCol) {
                    	sOut.append("<td width=\"10%\">");
                    	sOut.append("<textarea tabindex=\"<%= mCounter++ %>\" name=\"");
                    	sOut.append(x);
                    	sOut.append("\" cols=\"40\" rows=\"5\" maxlength=\"200\">");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("</textarea>");
                    	sOut.append("</td>");
                    }  else {
                    	sOut.append("<td>");
                    	sOut.append(aDb.getValue(x));

                    	sOut.append("<input type=\"hidden\" name=\"");
                    	sOut.append(x);
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\">");
                    	sOut.append("</td>");
                    }

                	// sOut.append("</td>");
                }
                sOut.append("<td><input type=\"submit\" class=\"butnTxt\" value=\"Save\" name=\"save\"></td>");
                sOut.append("</tr>");
                sOut.append("</form>");
                if(vRowClass.equals("datatablerowalt"))
                    vRowClass = "datatablerow";
                else
                if(vRowClass.equals("datatablerow"))
                    vRowClass = "datatablerowalt";
                aDb.moveNext();
            } while(!aDb.EOF());
        } else {

        	sOut.append("<table><tr><td><p>There are no requests for information for this programme area.</p></td></tr>");
        }
        sOut.append("</table>");
        return sOut.toString();
    }


    public static final String generateFormSubmitDataQuarterly(DbResults aDb,int aStartHideCol ,int aEndHideCol,int aStartCol,int aEndCol,int aTextStartCol,int aTextEndCol)
    {
        String vRowClass = "datatablerow";

        StringBuffer sOut = new StringBuffer(4096);

        if(aDb.hasRows())
        {
            sOut.append("<table align=\"center\" border=\"0\">").append("<tr class=\"datatableheaderrow\">");
            for(int x = 0; x < aDb.getColCount(); x++)

            	if (x >= aStartHideCol && x <= aEndHideCol) {
            		// do nothing
            	} else {
            		sOut.append("<th nowrap class=\"datatableheader\">").append(aDb.getColNames().get(x)).append("</th>");
            	}

            sOut.append("</tr>");

            aDb.moveFirst();
            do
            {
            	sOut.append("<form action=\"/uclbp/main.jsp?target=data\" method=\"post\" name=\"insdata\">");
            	sOut.append("<input type=\"hidden\" name=\"ins_quarterly_metric_value\" value=\"y\">");
            	sOut.append("<tr class=" + vRowClass + ">");
                for(int x = 0; x < aDb.getColCount(); x++) {

                    if (x >= aStartHideCol && x <= aEndHideCol) {
                    	// sOut.append(getValue(x));
                    	sOut.append("<input type=\"hidden\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\">");
                    } else if (x >= aStartCol && x <= aEndCol) {
                    	sOut.append("<td align=\"right\">");
                    	sOut.append("<div class=\"styleform\">");
                    	sOut.append("<input type=\"text\" pattern=\"[0-9]*\" tabindex=\"<%= mCounter++ %>\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\" size=\"5\" maxlength=\"10\">");
                    	sOut.append("</div>");
                    	sOut.append("</td>");
                    } else if (x >= aTextStartCol && x<= aTextEndCol) {
                    	sOut.append("<td width=\"10%\">");
                    	sOut.append("<textarea tabindex=\"<%= mCounter++ %>\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" cols=\"40\" rows=\"5\" maxlength=\"200\">");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("</textarea>");
                    	sOut.append("</td>");
                    } else if (x < aStartCol || x == (aTextEndCol + 1)){
                    	if (x < aStartCol) {
                    		sOut.append("<td nowrap>");
                    	}else  {
                    		sOut.append("<td>");
                    	}
                    	sOut.append(aDb.getValue(x));

                    	sOut.append("<input type=\"hidden\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\">");
                    	sOut.append("</td>");
                    }

                	// sOut.append("</td>");
                }
                sOut.append("<td><input type=\"submit\" class=\"butnTxt\" value=\"Save\" name=\"save\"></td>");

                sOut.append("</form>");
                sOut.append("</tr>");

                if(vRowClass.equals("datatablerowalt"))
                    vRowClass = "datatablerow";
                else
                if(vRowClass.equals("datatablerow"))
                    vRowClass = "datatablerowalt";
                aDb.moveNext();
            } while(!aDb.EOF());
        } else {
        	sOut.append("<table><tr><td><p>There are no requests for information.</p></td></tr>");
        }
        sOut.append("</table>");
        return sOut.toString();
    }

    public static final String generateFormSubmitDataOnetime(DbResults aDb,int aStartHideCol ,int aEndHideCol,int aStartCol,int aEndCol,int aTextStartCol,int aTextEndCol)
    {
        String vRowClass = "datatablerow";

        StringBuffer sOut = new StringBuffer(4096);

        if(aDb.hasRows())
        {
            sOut.append("<table align=\"center\" border=\"0\">").append("<tr class=\"datatableheaderrow\">");
            for(int x = 0; x < aDb.getColCount(); x++)

            	if (x >= aStartHideCol && x <= aEndHideCol) {
            		// do nothing
            	} else {
            		sOut.append("<th nowrap class=\"datatableheader\">").append(aDb.getColNames().get(x)).append("</th>");
            	}

            sOut.append("</tr>");

            aDb.moveFirst();
            do
            {
            	sOut.append("<form action=\"/uclbp/main.jsp?target=data\" method=\"post\" name=\"insdata\">");
            	sOut.append("<input type=\"hidden\" name=\"ins_onetime_metric_value\" value=\"y\">");
            	sOut.append("<tr class=" + vRowClass + ">");
                for(int x = 0; x < aDb.getColCount(); x++) {

                    if (x >= aStartHideCol && x <= aEndHideCol) {
                    	// sOut.append(getValue(x));
                    	sOut.append("<input type=\"hidden\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\">");
                    } else if (x >= aStartCol && x <= aEndCol) {
                    	sOut.append("<td align=\"right\">");
                    	sOut.append("<div class=\"styleform\">");
                    	sOut.append("<input type=\"text\" pattern=\"[0-9]*\" tabindex=\"<%= mCounter++ %>\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\" size=\"5\" maxlength=\"10\">");
                    	sOut.append("</div>");
                    	sOut.append("</td>");
                    } else if (x >= aTextStartCol && x<= aTextEndCol) {
                    	sOut.append("<td width=\"10%\">");
                    	sOut.append("<textarea tabindex=\"<%= mCounter++ %>\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" cols=\"40\" rows=\"5\" maxlength=\"200\">");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("</textarea>");
                    	sOut.append("</td>");
                    }  else {
                    	if (x < aStartCol) {
                    		sOut.append("<td nowrap>");
                    	}else {
                    		sOut.append("<td>");
                    	}
                    	sOut.append(aDb.getValue(x));

                    	sOut.append("<input type=\"hidden\" name=\"");
                    	sOut.append(aDb.getColNames().get(x));
                    	sOut.append("\" value=\"");
                    	sOut.append(aDb.getValue(x));
                    	sOut.append("\">");
                    	sOut.append("</td>");
                    }

                	// sOut.append("</td>");
                }
                sOut.append("<td><input type=\"submit\" class=\"butnTxt\" value=\"Save\" name=\"save\"></td>");
                sOut.append("</tr>");
                sOut.append("</form>");
                if(vRowClass.equals("datatablerowalt"))
                    vRowClass = "datatablerow";
                else
                if(vRowClass.equals("datatablerow"))
                    vRowClass = "datatablerowalt";
                aDb.moveNext();
            } while(!aDb.EOF());
        } else {
        	sOut.append("<table><tr><td><p>There are no requests for information.</p></td></tr>");
        }
        sOut.append("</table>");
        return sOut.toString();
    }

    public static final String generateSelectOrganization(DbResults aDb, String aOrganization_id)
    {
        StringBuffer sOut = new StringBuffer(4096);

        if(aDb.hasRows())
        {
            sOut.append("<select name=\"organization_id\" size=\"1\" tabindex=\"<%= mCounter++ %>\">");

            aDb.moveFirst();
            do
            {
            	sOut.append("<option value=\"");
            	sOut.append(aDb.getValue(0));
            	sOut.append("\"");

            	if (aOrganization_id.equals(aDb.getValue(0))) {
            		sOut.append(" selected");
            	}

            	sOut.append(">");
            	sOut.append(aDb.getValue(1));
            	sOut.append("</option>");

                aDb.moveNext();
            } while(!aDb.EOF());
        } else {
        	sOut.append("</select>");
        }
        return sOut.toString();
    }

    public static final String generateSelectArea(DbResults aDb, String aArea_id)
    {
        StringBuffer sOut = new StringBuffer(4096);

        if(aDb.hasRows())
        {
            sOut.append("<select name=\"area_id\" size=\"1\" tabindex=\"<%= mCounter++ %>\">");

            aDb.moveFirst();
            do
            {
            	sOut.append("<option value=\"");
            	sOut.append(aDb.getValue(0));
            	sOut.append("\"");

            	if (aArea_id.equals(aDb.getValue(0))) {
            		sOut.append(" selected");
            	}

            	sOut.append(">");
            	sOut.append(aDb.getValue(1));
            	sOut.append("</option>");

                aDb.moveNext();
            } while(!aDb.EOF());
        } else {
        	sOut.append("</select>");
        }
        return sOut.toString();
    }

    public static final String generateSelectGeography(DbResults aDb, String aGeography_id)
    {
        StringBuffer sOut = new StringBuffer(4096);

        if(aDb.hasRows())
        {
            sOut.append("<select name=\"geography_id\" size=\"1\" tabindex=\"<%= mCounter++ %>\">");

            aDb.moveFirst();
            do
            {
            	sOut.append("<option value=\"");
            	sOut.append(aDb.getValue(0));
            	sOut.append("\"");

            	if (aGeography_id.equals(aDb.getValue(0))) {
            		sOut.append(" selected");
            	}

            	sOut.append(">");
            	sOut.append(aDb.getValue(1));
            	sOut.append("</option>");

                aDb.moveNext();
            } while(!aDb.EOF());
        } else {
        	sOut.append("</select>");
        }
        return sOut.toString();
    }
}
