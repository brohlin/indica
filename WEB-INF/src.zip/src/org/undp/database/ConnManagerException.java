package org.undp.database;


public class ConnManagerException extends Exception
{

    public ConnManagerException()
    {
    }

    public ConnManagerException(String aStr)
    {
        super(aStr);
    }
}
